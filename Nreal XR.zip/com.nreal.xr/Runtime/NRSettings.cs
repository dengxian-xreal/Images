/****************************************************************************
* Copyright 2019 Xreal Techonology Limited. All rights reserved.
*                                                                                                                                                          
* This file is part of NRSDK.                                                                                                          
*                                                                                                                                                           
* https://www.xreal.com/        
* 
*****************************************************************************/

namespace Unity.XR.NRSDK
{
    using UnityEditor;
    using UnityEngine;
    using UnityEngine.XR.Management;

    [System.Serializable]
    [XRConfigurationData("NRSDK", NRConstants.k_SettingsKey)]
    public class NRSettings : ScriptableObject
    {
        public enum StereoRenderingModeAndroid
        {
            Mutlipass = 0,
            
            /// <summary>
            /// Unity uses a single texture array with two elements. 
            /// Multiview is very similar to Single Pass Instanced; however, the graphics driver converts each call into an instanced draw call so it requires less work on Unity's side. 
            /// As with Single Pass Instanced, shaders need to be aware of the Multiview setting. Unity's shader macros handle the situation.
            /// </summary>
            Multiview = 2
        }

        /// <summary>
        /// The current stereo rendering mode selected for Android-based Xreal platforms
        /// </summary>
        [SerializeField, Tooltip("Set the Stereo Rendering Method")]
        public StereoRenderingModeAndroid m_StereoRenderingModeAndroid = StereoRenderingModeAndroid.Multiview;
        [HideInInspector]
        public bool m_UseMultiThread = false;

        public ushort GetStereoRenderingMode()
        {
#if UNITY_ANDROID && !UNITY_EDITOR
            return (ushort)m_StereoRenderingModeAndroid;
# else
            return 0;
#endif
        }

        public bool GetMultiThreadMode()
        {
#if UNITY_ANDROID && !UNITY_EDITOR
            return m_UseMultiThread;
#else
            return PlayerSettings.GetMobileMTRendering(BuildTargetGroup.Android);
#endif
        }

#if !UNITY_EDITOR
		public static NRSettings s_Settings;

		public void Awake()
		{
			s_Settings = this;
		}
#endif
    }
}
