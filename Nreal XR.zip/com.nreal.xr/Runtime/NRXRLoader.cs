﻿/****************************************************************************
* Copyright 2019 Xreal Techonology Limited. All rights reserved.
*                                                                                                                                                          
* This file is part of NRSDK.                                                                                                          
*                                                                                                                                                           
* https://www.xreal.com/        
* 
*****************************************************************************/

namespace Unity.XR.NRSDK
{
    using System.Collections.Generic;
    using UnityEditor;
    using UnityEngine;
    using UnityEngine.XR;
    using UnityEngine.XR.Management;
    using System.Runtime.InteropServices;

    public class NRXRLoader : XRLoaderHelper
    {
#if USING_NR_SERVICE
        const string NRNativeLibrary = "libnr_service.so"; 
#else
        const string NRNativeLibrary = "libnr_loader.so";
#endif

        //     private static List<XRDisplaySubsystemDescriptor> s_DisplaySubsystemDescriptors =
        //         new List<XRDisplaySubsystemDescriptor>();
        //     private static List<XRInputSubsystemDescriptor> s_InputSubsystemDescriptors =
        //         new List<XRInputSubsystemDescriptor>();

        //     public XRDisplaySubsystem displaySubsystem
        //     {
        //         get
        //         {
        //             return GetLoadedSubsystem<XRDisplaySubsystem>();
        //         }
        //     }

        //     public XRInputSubsystem inputSubsystem
        //     {
        //         get
        //         {
        //             return GetLoadedSubsystem<XRInputSubsystem>();
        //         }
        //     }

        public override bool Initialize()
        {
            Debug.Log("[XR][NRXRLoader] Initialize");
            UserDefinedSettings userDefinedSettings = new UserDefinedSettings();
            userDefinedSettings.nativeSDKLib = NRNativeLibrary;
#if UNITY_ANDROID && !UNITY_EDITOR
            NRSettings settings = GetSettings();
            if (settings != null)
            {
                userDefinedSettings.stereoRenderingMode = (ushort)settings.GetStereoRenderingMode();
                userDefinedSettings.colorSpace = (ushort)((QualitySettings.activeColorSpace == ColorSpace.Linear) ? 1 : 0);
                userDefinedSettings.useMultiThread = settings.GetMultiThreadMode();
                InitUserDefinedSettings(userDefinedSettings);
            }
            else
            {
                Debug.Log("[XR][NRXRLoader] Settings is null!");
                userDefinedSettings.stereoRenderingMode = (ushort)NRSettings.StereoRenderingModeAndroid.Multiview;
                userDefinedSettings.useMultiThread = false;
                InitUserDefinedSettings(userDefinedSettings);
            }
#endif
            Debug.Log("[XR][NRXRLoader] Settings:" + userDefinedSettings.ToString());

            Debug.Log("[XR][NRXRLoader] Create");
            // CreateSubsystem<XRDisplaySubsystemDescriptor, XRDisplaySubsystem>(s_DisplaySubsystemDescriptors, "NRSDK Display");
            // CreateSubsystem<XRInputSubsystemDescriptor, XRInputSubsystem>(s_InputSubsystemDescriptors, "NRSDK Head Tracking");

            // if (displaySubsystem == null || inputSubsystem == null)
            // {
            //     Debug.Log("[XR][NRXRLoader] Unable to start NRSDK XR Plugin.");
            //     return false;
            // }

            return true;
        }

        public override bool Start()
        {
            // Debug.Log("[XR][NRXRLoader] Start");
            // StartSubsystem<XRDisplaySubsystem>();
            // StartSubsystem<XRInputSubsystem>();
            return true;
        }

        public override bool Stop()
        {
            // Debug.Log("[XR][NRXRLoader] Stop");
            // StopSubsystem<XRDisplaySubsystem>();
            // StopSubsystem<XRInputSubsystem>();
            return true;
        }

        public override bool Deinitialize()
        {
            // Debug.Log("[XR][NRXRLoader] Deinitialize");
            // DestroySubsystem<XRDisplaySubsystem>();
            // DestroySubsystem<XRInputSubsystem>();
            return true;
        }

        [StructLayout(LayoutKind.Sequential)]
        struct UserDefinedSettings
        {
            public ushort stereoRenderingMode;
            public ushort colorSpace;
            public bool useMultiThread;
            public string nativeSDKLib;

            public override string ToString()
            {
                return string.Format("stereoRenderingMode:{0} colorSpace:{1} useMultiThread:{2} nativeSDKLib:{3}",
                    stereoRenderingMode, colorSpace, useMultiThread, nativeSDKLib);
            }
        }

#if !UNITY_EDITOR && UNITY_ANDROID
        [DllImport("NrealXRPlugin", CharSet = CharSet.Auto)]
        static extern void InitUserDefinedSettings(UserDefinedSettings settings);
#endif

        public static NRSettings GetSettings()
        {
            NRSettings settings = null;
#if UNITY_EDITOR
            EditorBuildSettings.TryGetConfigObject<NRSettings>(NRConstants.k_SettingsKey, out settings);
#else
            settings = NRSettings.s_Settings;
#endif
            return settings;
        }
    }
}
